package cn.seejoy.hardware;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;
/**
 * ????????
 * 
 * @author ???
 * @since 2016-9-21
 * @serial V1.0
 */
@SuppressLint("ViewConstructor")
public class KeyboardView extends RelativeLayout {
	
	protected static final char[] KEY_88 = "0100101001010100101001010100101001010100101001010100101001010100101001010100101001010100".toCharArray();
	
	private Context context;
	
	private ViewGroup.LayoutParams params;
	/**
	 * ????????
	 */
	private KeyboardStyle style;
	/**
	 * ??????
	 */
	private List<PianoKey> keyList;
	
	public KeyboardView(Context context, KeyboardStyle style, ViewGroup.LayoutParams layoutParams) {
		super(context);
		this.context = context;
		this.style = style;
		this.params = layoutParams;
		this.keyList = new ArrayList<PianoKey>();
		((Activity)context).addContentView(this, layoutParams);
//		this.setBackgroundColor(Color.RED);
		createKeys();
	}
	
	/**
	 * ???????
	 */
	@SuppressLint("NewApi")
	private void createKeys() {

		PianoKey pk = null;
		float whiteX = 0;
		int w = this.params.width;
		int h = this.params.height;
		int whiteWidth = (int) Math.ceil(w / 52.0);
		int blackWidth = (int) (whiteWidth * 0.45);
		int blackHeight = (int) (h * 0.66);
		if (style == KeyboardStyle.Key88) {
			int midi = 22;
			for(char t : KEY_88) {
				if (t == '0') {
					LayoutParams lp = new LayoutParams(whiteWidth, h);
					pk = new PianoKey(this.context, this, PianoKeyStyle.White, lp, midi++);
					pk.setX(whiteX);
					whiteX += whiteWidth;
				} else {
					int x = (int) ((pk.getX() + whiteWidth) - (blackWidth / 2));
					LayoutParams lp = new LayoutParams(blackWidth, blackHeight);
					pk = new PianoKey(this.context, this, PianoKeyStyle.Black, lp, midi++);
					pk.setX(x);
				}
			}
		}
		this.keyList.add(pk);
	}

	/**
	 * ????x,y??????midi?
	 * @param x
	 * @param y
	 * @return int
	 */
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public int getMidi(float x, float y) {
		int midi = 0;
		float yt = y - this.getY();
		int isFound = -1;
		PianoKey key = null;
		for (int i = 0; i < this.keyList.size(); i++) {
			
			key = this.keyList.get(i);
			if (		x >= key.getX()
					&& yt >= key.getY()
					&& x <= (key.getX() + key.getHeight())
					&& yt <= (key.getY() + key.getWidth())) {
				
				isFound = i;
				midi = key.getMidi();
				if (key.getStyle() == PianoKeyStyle.Black) {
					break;
				}
			}
			if ((i - isFound) > 1) {
				break;
			}
		}
		return midi;
	}
	
	/**
	 * ???
	 */
	protected class PianoKey extends View {

		private static final int WHITE_KEY_LINE_COLOR = Color.RED;
		
		private static final int BLACK_KEY_BACK_COLOR = Color.RED;
		
		private int midi;
		
		private PianoKeyStyle style;
		
		public PianoKey(Context context, ViewGroup parent, PianoKeyStyle style, LayoutParams params, int midi) {
			super(context);
			this.style = style;
			this.midi = midi;
//			((Activity)context).addContentView(this, params);
			parent.addView(this, -10, params);
		}
		/**
		 * ?????
		 */
		@Override
		protected void onDraw(Canvas canvas) {
			
			if (this.style == PianoKeyStyle.White) {
				 Paint paint = new Paint();  
				 paint.setColor(WHITE_KEY_LINE_COLOR);  

				 int width = this.getWidth();  
				 int height = this.getHeight();  

				 canvas.drawLine(0, 0, 0, height, paint);
				 canvas.drawLine(0, 0, width, 0, paint);
				 canvas.drawLine(width - 1, 0, width - 1, height, paint);  
				 canvas.drawLine(0, height - 1, width, height - 1, paint);  

			} else if (this.style == PianoKeyStyle.Black) {
				this.setBackgroundColor(BLACK_KEY_BACK_COLOR);
			}
			super.onDraw(canvas);
		}

		/**
		 * ???MIDI?
		 * @return int
		 */
		public int getMidi() {
			return midi;
		}

		/**
		 * ????????????????
		 * @return PianoKeyStyle
		 */
		public PianoKeyStyle getStyle() {
			return style;
		}
	}
}


/**
 * ????????
 * 
 * @author ???
 * @since 2016
 * @serial V1.0
 */
enum KeyboardStyle {  
	  Key88
} 

/**
 * ????????
 * 
 * @author ???
 * @since 2016
 * @serial V1.0
 */
enum PianoKeyStyle {  
	  Black, White;
} 