package cn.seejoy.hardware;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.SurfaceView;
import android.view.WindowManager;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Mat;

public class MainActivity extends AppCompatActivity implements CameraBridgeViewBase.CvCameraViewListener2 {

    private static final String TAG = "OCVSample::Activity";

    private AudioMidi audio;

    private CameraBridgeViewBase mOpenCvCameraView;
    private boolean              mIsJavaCamera = true;
    private MenuItem mItemSwitchCamera = null;

    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:
                {
                    Log.i(TAG, "OpenCV loaded successfully");
                    mOpenCvCameraView.enableView();
                } break;
                default:
                {
                    super.onManagerConnected(status);
                } break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //setContentView(R.layout.tutorial1_surface_view);
        setContentView(R.layout.activity_main);

        mOpenCvCameraView = (CameraBridgeViewBase) findViewById(R.id.tutorial1_activity_java_surface_view);

        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);

        mOpenCvCameraView.setCvCameraViewListener(this);

        audio = new AudioMidi();
    }


    @Override
    public void onPause()
    {
        super.onPause();
        if (mOpenCvCameraView != null) {
            mOpenCvCameraView.disableView();
        }

        audio.release();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "Internal OpenCV library not found. Using OpenCV Manager for initialization");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
        audio.init();
    }

    public void onDestroy() {
        super.onDestroy();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    public void onCameraViewStarted(int width, int height) {
    }

    public void onCameraViewStopped() {
    }

    public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {
//        Mat grayMat = new Mat();
//        Imgproc.cvtColor(inputFrame.rgba(), grayMat, Imgproc.COLOR_RGB2GRAY);//rgbMat to gray grayMat
//        return grayMat;
        Log.d("zhangshuai", "onCameraFrame");

//        Mat src = inputFrame.rgba();
//        Mat dst = new Mat(src.size(), src.type());
//
//        List<Point> pts_src = new ArrayList<>();
////        Point[] pts_src = new Point[4];
//        List<Point> pts_dst = new ArrayList<>();
////        Point[] pts_dst = new Point[4];
//        int offset_x, offset_y;
//
//        //映射关系 (310,281)->(300,200)      (193,14)->(300,50)           (928,14)->(800,50)       (744,281)->(800,200)
//        offset_x = 0;//为正，横向拉伸，为负，横向压缩
//        offset_y = 150;//为正，纵向拉伸，为负，纵向压缩
//
//        pts_src.add(new Point(0, 768));   pts_dst.add(new Point(0-offset_x, 768+offset_y));
//        pts_src.add(new Point(0, 0));    pts_dst.add(new Point(0-offset_x, 0-offset_y));
//        pts_src.add(new Point(1280, 768));    pts_dst.add(new Point(1280+offset_x, 768+offset_y));
//        pts_src.add(new Point(1280, 0));   pts_dst.add(new Point(1280+offset_x, 0-offset_y));
//
////        pts_src[0] = new Point();
////        pts_src[1] = new Point();
////        pts_src[2] = new Point();
////        pts_src[3] = new Point();
////        pts_src[0].x = 310;
////        pts_src[0].y = 281;
////        pts_src[1].x = 193;
////        pts_src[1].y = 14;
////        pts_src[2].x = 928;
////        pts_src[2].y = 14;
////        pts_src[3].x = 744;
////        pts_src[3].y = 281;
//
////        pts_dst[0] = new Point();
////        pts_dst[1] = new Point();
////        pts_dst[2] = new Point();
////        pts_dst[3] = new Point();
////        pts_dst[0].x = 300-offset_x;
////        pts_dst[0].y = 200+offset_y;
////        pts_dst[1].x = 300-offset_x;
////        pts_dst[1].y = 50-offset_y;
////        pts_dst[2].x = 800+offset_x;
////        pts_dst[2].y = 50-offset_y;
////        pts_dst[3].x = 800+offset_x;
////        pts_dst[3].y = 200+offset_y;
//
//
//        MatOfPoint2f ptsSrc = new MatOfPoint2f(pts_src.toArray(new Point[0]));
//        MatOfPoint2f ptsDst = new MatOfPoint2f(pts_dst.toArray(new Point[0]));
//        Mat disMat = Imgproc.getPerspectiveTransform(ptsSrc, ptsDst);
//        Imgproc.warpPerspective(src, dst, disMat, src.size());


//        return ImageConvert.wideAngleRecover(inputFrame.gray());
        return ImageConvert.wideAngleRecover4(inputFrame.rgba());

//        return inputFrame.gray();
    }
}
