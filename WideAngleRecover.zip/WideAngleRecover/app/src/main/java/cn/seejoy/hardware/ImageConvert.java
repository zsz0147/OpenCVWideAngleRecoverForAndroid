package cn.seejoy.hardware;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Range;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by itserver on 2016/10/12.
 */

public class ImageConvert {

    /**
     * 图像变T形
     *
     * @param mat
     * @return
     */
    public static Mat wideAngleRecover(Mat mat) {

        Mat src = new Mat(mat, new Range(350, mat.height() - 50), Range.all());
//        Mat src = mat;
        Mat dst = new Mat(src.size(), src.type());

        List<Point> pts_src = new ArrayList<>();
//        Point[] pts_src = new Point[4];
        List<Point> pts_dst = new ArrayList<>();
//        Point[] pts_dst = new Point[4];
        int offset_x, offset_y;

        //映射关系 (310,281)->(300,200)      (193,14)->(300,50)           (928,14)->(800,50)       (744,281)->(800,200)
        offset_x = 200;//为正，横向拉伸，为负，横向压缩
        offset_y = -40;//为正，纵向拉伸，为负，纵向压缩

        pts_src.add(new Point(0, 0));
        pts_dst.add(new Point(0, 0 - offset_y));
        pts_src.add(new Point(0, src.height()));
        pts_dst.add(new Point(0 + offset_x, src.height()));
        pts_src.add(new Point(src.width(), 0));
        pts_dst.add(new Point(src.width(), 0 - offset_y));
        pts_src.add(new Point(src.width(), src.height()));
        pts_dst.add(new Point(src.width() - offset_x, src.height()));

        MatOfPoint2f ptsSrc = new MatOfPoint2f(pts_src.toArray(new Point[0]));
        MatOfPoint2f ptsDst = new MatOfPoint2f(pts_dst.toArray(new Point[0]));
        Mat disMat = Imgproc.getPerspectiveTransform(ptsSrc, ptsDst);
        Imgproc.warpPerspective(src, dst, disMat, src.size());

        return dst;
    }

    public static Mat wideAngleRecover2(Mat mat) {

        Mat src = new Mat(mat, new Range(350, mat.height() - 50), Range.all());

        return src;
    }


    public static Mat wideAngleRecover3(Mat mat) {
//        cvUndistort2
        Mat src = mat;
        Mat dst = new Mat(src.size(), src.type());

        Size imgSize = src.size();
/*
        double[] intr_mat = new double[]{
                1000, 0, imgSize.width / 2.0f,
                0, 1000, imgSize.height * 0.5f,
                0, 0, 1};

        Mat intrinsicMatrix = new Mat(3, 3, CvType.CV_32F, new Scalar(intr_mat));

        double[] dist_coef = new double[]{
                10.5, 10.5, 0, 0
        };
        */
        double[] intr_mat = new double[]{
                10, 0, imgSize.width / 2.0f,
                0, 10, imgSize.height * 0.5f,
                0, 0, 1};

        Mat intrinsicMatrix = new Mat(3, 3, CvType.CV_32F, new Scalar(intr_mat));

        double[] dist_coef = new double[]{
                -10.5, -10.5, 0, 0
        };

        Mat distortion_coeffs = new Mat(1, 4, CvType.CV_32F, new Scalar(dist_coef));
        Imgproc.undistort(src, dst, intrinsicMatrix, distortion_coeffs);
//        Imgproc.initUndistortRectifyMap();
//        Imgproc.initWideAngleProjMap()
        return dst;
    }

    public static Mat wideAngleRecover4(Mat mat) {
        Mat src = mat;
        Mat dst = new Mat(new Size(1280, 960), CvType.CV_32FC1);
        Mat dst1 = new Mat(new Size(1280, 960), CvType.CV_32FC1);
        Mat dst2 = new Mat(new Size(1280, 960), CvType.CV_32FC1);
        Size imgSize = src.size();

//        double[] intr_mat = new double[]{
//                1000, 0, imgSize.width / 2.0f,
//                0, 1000, imgSize.height * 0.5f,
//                0, 0, 1};;
//        Mat intrinsicMatrix = new Mat(3, 3, CvType.CV_32FC1, new Scalar(intr_mat));

        Mat intrinsicMatrix = new Mat();
        Mat.eye(3, 3, CvType.CV_32FC1).copyTo(intrinsicMatrix);
//        intrinsicMatrix.setTo(new Scalar(intr_mat));
        intrinsicMatrix.put(0,0,1000);
        intrinsicMatrix.put(0,1,0);
        intrinsicMatrix.put(0,2,imgSize.width / 2.0f);
        intrinsicMatrix.put(1,0,0);
        intrinsicMatrix.put(1,1,1000);
        intrinsicMatrix.put(1,2,imgSize.height * 0.5f);
        intrinsicMatrix.put(2,0,0);
        intrinsicMatrix.put(2,1,0);
        intrinsicMatrix.put(2,2,1);

//        intrinsicMatrix.put(
//                1000, 0, imgSize.width / 2.0f,
//                            0, 1000, imgSize.height * 0.5f,
//                            0, 0, 1
//                );

//        double[] dist_coef = new double[] {
//                0.23, 0.69, 0, 0, 0
//        };
//        Mat distortion_coeffs = new Mat(1, 5, CvType.CV_32FC1, new Scalar(dist_coef));
        Mat distortion_coeffs = new Mat();
        Mat.eye(1, 5, CvType.CV_32FC1).copyTo(distortion_coeffs);
        distortion_coeffs.put(0, 0, -0.3);
        distortion_coeffs.put(0, 1, -0.3);
        distortion_coeffs.put(0, 2, 0);
        distortion_coeffs.put(0, 3, 0);
        distortion_coeffs.put(0, 4, 0);

//        Imgproc.initWideAngleProjMap(intrinsicMatrix, distortion_coeffs, new Size(1280, 960), src.width(), dst1.type(), dst1, dst2);
//        Imgproc.remap(src, dst, dst1, dst2, Imgproc.INTER_LINEAR);

        Imgproc.initUndistortRectifyMap(intrinsicMatrix, distortion_coeffs, new Mat(), intrinsicMatrix, new Size(1280, 960), dst1.type(), dst1, dst2);
        Imgproc.remap(src, dst, dst1, dst2, Imgproc.INTER_LINEAR);
        return dst;
    }

}