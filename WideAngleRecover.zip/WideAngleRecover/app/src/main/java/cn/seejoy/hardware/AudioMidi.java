package cn.seejoy.hardware;

import android.util.Log;

import org.billthefarmer.mididriver.MidiDriver;

/**
 * MIDI播放类 on 2016/10/13.
 */

public class AudioMidi implements MidiDriver.OnMidiStartListener {

    /**
     * MIDI初始化
     */
//    public void setupMidi() {
//        midiDriver = new MidiDriver();
//        midiDriver.setOnMidiStartListener(this);
//    }

    private MidiDriver midiDriver;


    public AudioMidi(){
        midiDriver = new MidiDriver();
        midiDriver.setOnMidiStartListener(this);
    }

    /**
     * 播放MIDI
     * @param midi
     */
    public void playNote(int midi) {
        byte[] event = new byte[3];
        event[0] = (byte) (0x90 | 0x00);  // 0x90 = note On, 0x00 = channel 1
        event[1] = (byte) midi;  // 0x3C = middle C
        event[2] = (byte) 0x7F;  // 0x7F = the maximum velocity (127)
        midiDriver.write(event);
    }

    /**
     * 停止MIDI
     * @param midi
     */
    public void stopNote(int midi) {
        byte[] event = new byte[3];
        event[0] = (byte) (0x80 | 0x00);  // 0x80 = note Off, 0x00 = channel 1
        event[1] = (byte) midi;  // 0x3C = middle C
        event[2] = (byte) 0x00;  // 0x00 = the minimum velocity (0)
        midiDriver.write(event);
    }

    /**
     * 销毁
     */
    public void init() {
        midiDriver.start();
    }

    /**
     * 销毁
     */
    public void release() {
        midiDriver.stop();
    }

    @Override
    public void onMidiStart() {
        Log.d("--CT--", "onMidiStart()");
    }
}
